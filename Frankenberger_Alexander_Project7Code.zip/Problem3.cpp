#include <iostream>
using namespace std;

int main() {
    // Initialize variables, starting with 1 and 2
    int t1 = 1;
    int t2 = 2;
    int nextTerm = 0;

    cout << "Fibonacci Series: ";


    // Continue running as long as the current number is less than or equal to 4 million
    while (t1 <= 4000000) {
        cout << t1 << ", "; // Print the current term

        // Calculate the next term
        nextTerm = t1 + t2;

        // Shift the values forward for the next iteration
        t1 = t2;      
        t2 = nextTerm; 
    }
    cout << endl;
    return 0;
}