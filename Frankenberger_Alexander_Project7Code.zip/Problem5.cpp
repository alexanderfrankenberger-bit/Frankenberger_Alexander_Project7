#include <iostream>
#include <vector>
using namespace std;

// Function to print the first n rows of Pascal's Triangle
void printPascal(int n) {
    if (n <= 0) return;

    // Start with the first row
    vector<int> prevRow;
    prevRow.push_back(1);
    
    // Print the first row manually
    cout << "1" << endl;

    // Loop to generate the remaining n-1 rows
    for (int i = 1; i < n; i++) {
        vector<int> currentRow;
        
        // Every row starts with 1
        currentRow.push_back(1);

        // Calculate middle values: sum of the two numbers above
        // We look at the 'prevRow' to calculate 'currentRow'
        for (int j = 0; j < prevRow.size() - 1; j++) {
            int sum = prevRow[j] + prevRow[j+1];
            currentRow.push_back(sum);
        }

        // Every row ends with 1
        currentRow.push_back(1);

        // Print the current row
        for (int k = 0; k < currentRow.size(); k++) {
            cout << currentRow[k] << " ";
        }
        cout << endl;

        // Update prevRow so the next iteration can use this row
        prevRow = currentRow;
    }
}

int main() {
    int n;
    cout << "Enter the number of rows for Pascal's Triangle: ";
    cin >> n;
    
    printPascal(n);

    return 0;
}