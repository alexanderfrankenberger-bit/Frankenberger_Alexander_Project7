#include <iostream>
#include <vector>

using namespace std;

void print_vector(vector<int> v) {
    // Loop through every integer 'n' in the vector 'v'
    for (int i = 0; i < v.size(); i++) {
        cout << v[i] << " "; // Print the number followed by a space
    }
    cout << endl;
}

int main() {
    // Test
    vector<int> myNumbers = {10, 25, 60, 4, 190};

    cout << "The vector contains: ";
    print_vector(myNumbers);

    return 0;
}