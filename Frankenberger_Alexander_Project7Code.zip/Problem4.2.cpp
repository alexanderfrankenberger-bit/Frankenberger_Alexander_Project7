#include <iostream>
#include <vector>
using namespace std;

// Print vector from problem 2
void print_vector(vector<int> v) {
    for (int i = 0; i < v.size(); i++) {
        cout << v[i] << " ";
    }
    cout << endl;
}

// Factorizing Part
vector<int> factorize(int n) {
    vector<int> answer;

    // Loop from 1 up to n
    for (int i = 1; i <= n; i++) {
        // If n divides by i evenly (remainder is 0), it's a factor
        if (n % i == 0) {
            answer.push_back(i);
        }
    }

    return answer;
}
// tests

void test_factorize() {
    cout << "Factors of 2: ";
    print_vector(factorize(2));

    cout << "Factors of 72: ";
    print_vector(factorize(72));

    cout << "Factors of 196: ";
    print_vector(factorize(196));
}

int main() {
    test_factorize();
    return 0;
}