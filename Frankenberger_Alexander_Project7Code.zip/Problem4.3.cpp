#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

// Print Vector from problem 2
void print_vector(vector<int> v) {
    for (int i = 0; i < v.size(); i++) {
        cout << v[i] << " ";
    }
    cout << endl;
}

// Prime Factorization
vector<int> prime_factorize(int n) {
    vector<int> answer;

 
    // For even factors, while n is even, add 2 to the list and divide n by 2
    while (n % 2 == 0) {
        answer.push_back(2);
        n = n / 2;
    }


    // For odd factors, start at 3 and skip even numbers
    for (int i = 3; i * i <= n; i += 2) {
        while (n % i == 0) {
            answer.push_back(i);
            n = n / i;
        }
    }

    // If n is still > 2, the remaining n is a prime factor itself
    if (n > 2) {
        answer.push_back(n);
    }

    return answer;
}
// Test cases

void test_prime_factorize() {
    cout << "Prime factors of 2: ";
    print_vector(prime_factorize(2));

    cout << "Prime factors of 72: ";
    print_vector(prime_factorize(72)); 

    cout << "Prime factors of 196: ";
    print_vector(prime_factorize(196)); 
}

int main() {
    test_prime_factorize();
    return 0;
}