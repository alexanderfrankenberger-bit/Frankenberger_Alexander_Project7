#include <iostream>

using namespace std;

int main() {
    int n;

    // input
    cout << "Enter a number: ";
    cin >> n;

    // switch n
    switch (n) {
        case -1:
            // disp('negative one')
            cout << "negative one" << endl;
            break; 

        case 0:
            // disp('zero')
            cout << "zero" << endl;
            break;

        case 1:
            // disp('positive one')
            cout << "positive one" << endl;
            break;

        default: // otherwise
            // disp('other value')
            cout << "other value" << endl;
            break;
    }

    return 0;
}