#include <iostream>
using namespace std;

bool isprime(int n) {
    bool result = true; // Assume the number is prime first

    // Edge case: 0 and 1 are not prime numbers
    if (n <= 1) {
        result = false;
    }

    // Check for divisors
    // Loops from 2 up to n-1. If it finds any number that divides n evenly, then n is NOT prime.
    for (int i = 2; i < n; i++) {
        if (n % i == 0) {
            result = false;
            break; // Found a divisor, so stop checking
        }
    }

    return result;
}

void test_isprime() {
    // true prints as 1 and false prints as 0.
    cout << "isprime(2) = " << isprime(2) << endl;   
    cout << "isprime(10) = " << isprime(10) << endl; 
    cout << "isprime(17) = " << isprime(17) << endl; 
}

int main() {
    test_isprime();
    return 0;
}